package com.example.jet1words

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.util.Calendar
import java.util.Locale

class MainActivity : AppCompatActivity() {

    // ---------------- Data ----------------
    private val words = listOf(
        "bag" to "תיק", "banana" to "בננה", "Dad" to "אבא", "bad" to "רע", "egg" to "ביצה",
        "bed" to "מיטה", "sad" to "עצוב", "hat" to "כובע", "test" to "מבחן", "pen" to "עט",
        "hen" to "תרנגול", "hand" to "יד", "help" to "לעזור", "big" to "גדול", "stop" to "לעצור",
        "hot" to "חם", "cold" to "קר", "lost" to "אבד", "dog" to "כלב", "job" to "עבודה",
        "plan" to "תוכנית", "pet" to "חיית מחמד", "leg" to "רגל", "grandpa" to "סבא", "lamp" to "מנורה",
        "mat" to "שטיחון", "sing" to "לשיר", "ten" to "עשר", "mad" to "כועס", "glad" to "שמח",
        "cat" to "חתול", "on" to "על", "in" to "בתוך", "add" to "להוסיף", "mom" to "אמא",
        "lemon" to "לימון", "melon" to "מלון", "grandma" to "סבתא", "and" to "ו (מילת חיבור)", "panda" to "פנדה"
    )
    private val sightWords = listOf(
        "Look" to "להסתכל", "I am" to "אני", "He" to "הוא", "She" to "היא", "Have" to "יש ל...",
        "Has" to "יש ל... (לו / לה)", "The" to "ה הידיעה", "Like" to "לאהוב", "Want" to "לרצות",
        "Girl" to "ילדה", "Boy" to "ילד"
    )
    private val extraCvc = listOf(
        "sun" to "שמש", "cup" to "כוס", "bus" to "אוטובוס", "red" to "אדום", "run" to "לרוץ", "sit" to "לשבת",
        "pig" to "חזיר", "fox" to "שועל", "box" to "קופסה", "bat" to "עטלף", "cap" to "כובע מצחייה", "map" to "מפה",
        "net" to "רשת", "pin" to "סיכה", "top" to "צמרת", "mug" to "ספל", "jam" to "ריבה", "hug" to "חיבוק",
        "lip" to "שפה", "web" to "קורי עכביש"
    )
    private fun cvcWords() = words.filter { it.first.length == 3 } + extraCvc

    private val letters = ('A'..'Z').map { "$it${it.lowercaseChar()}" to "$it" }
    private val letterWords = mapOf(
        'A' to ("apple" to "🍎"), 'B' to ("ball" to "⚽"), 'C' to ("cat" to "🐱"), 'D' to ("dog" to "🐶"),
        'E' to ("egg" to "🥚"), 'F' to ("fish" to "🐟"), 'G' to ("girl" to "👧"), 'H' to ("hat" to "👒"),
        'I' to ("insect" to "🐛"), 'J' to ("juice" to "🧃"), 'K' to ("kite" to "🪁"), 'L' to ("lion" to "🦁"),
        'M' to ("monkey" to "🐒"), 'N' to ("nose" to "👃"), 'O' to ("octopus" to "🐙"), 'P' to ("panda" to "🐼"),
        'Q' to ("queen" to "👑"), 'R' to ("rabbit" to "🐰"), 'S' to ("sun" to "☀️"), 'T' to ("tiger" to "🐯"),
        'U' to ("umbrella" to "☂️"), 'V' to ("van" to "🚐"), 'W' to ("whale" to "🐋"), 'X' to ("box" to "📦"),
        'Y' to ("yo-yo" to "🪀"), 'Z' to ("zebra" to "🦓")
    )
    private val items = listOf(
        "cat" to "🐱", "dog" to "🐶", "hen" to "🐔", "panda" to "🐼", "hat" to "👒", "bag" to "🎒",
        "pen" to "🖊️", "bed" to "🛏️", "egg" to "🥚", "banana" to "🍌", "lemon" to "🍋", "melon" to "🍈"
    )

    // Other things the recognizer commonly hears when the word was said correctly
    private val aliases = mapOf(
        "bag" to "bags bague", "banana" to "bananas", "dad" to "dads daddy dat", "bad" to "bads bat",
        "egg" to "eggs eg ag ecg", "bed" to "bet bedd beds", "sad" to "sat said sed", "hat" to "hats had hut at hurt",
        "test" to "tests text tast", "pen" to "pens penn pan", "hen" to "hens when then ben en een", "hand" to "hands han and an handed",
        "help" to "helps helped elp kelp yelp held hell", "big" to "bick bigg", "stop" to "stops stopp", "hot" to "hut hots ot hott what",
        "cold" to "called coal colt", "lost" to "lust last", "dog" to "dogs doug dug", "job" to "jobs jab jog",
        "plan" to "plans plant plane", "pet" to "pets pat bet pit", "leg" to "legs lag lek", "grandpa" to "grandpas grampa gramps grandfather",
        "lamp" to "lamps lamb ramp", "mat" to "mats matt mutt met", "sing" to "sings sink singh", "ten" to "then tin tan",
        "mad" to "made mud med", "glad" to "clad glade gland", "cat" to "cats kat cut cap", "on" to "own un ahn",
        "in" to "inn n", "add" to "ad adds", "mom" to "mum mama mommy mam", "lemon" to "lemons lemmon",
        "melon" to "melons mellon malone", "grandma" to "grandmas gramma grandmother", "and" to "an n end ann ant", "panda" to "pandas pander",
        "look" to "looks luck lock", "i am" to "iam im am", "have" to "half halve ave av", "has" to "as haz hass az hz his",
        "the" to "thee da duh thuh tha de", "like" to "likes liked lyke", "he" to "hey hee hi e ee who", "she" to "shea shi",
        "want" to "wont once wanted wan", "girl" to "gal curl grill gir", "boy" to "buoy boi bye",
        "sun" to "son one", "cup" to "cop cap cut", "bus" to "boss bass buzz", "red" to "read rid", "run" to "ron one",
        "sit" to "set sick sat", "pig" to "big peg pick", "fox" to "folks box", "box" to "books bucks", "bat" to "bad bet bart",
        "cap" to "cup cat kap", "map" to "mop mat mac", "net" to "nut not neck", "pin" to "pen ping", "top" to "tap tip tub",
        "mug" to "mom mud mark", "jam" to "jem gem ham", "hug" to "hog hack ug", "lip" to "lib lap leap", "web" to "wet wed ebb"
    )

    private data class Q(
        val prompt: String, val spoken: String, val label: String,
        val options: List<String>, val answer: Int, val big: Boolean, val perRow: Int,
        val hint: String = "", val autoSpeak: Boolean = true, val ps: Float = 0f
    )

    // ---------------- State ----------------
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var pendingSpeak: (() -> Unit)? = null
    private var recognizer: SpeechRecognizer? = null

    private var queue = listOf<Pair<String, String>>()
    private var quiz = listOf<Q>()
    private var index = 0
    private var qi = 0
    private var score = 0
    private var tries = 0
    private var autoRetry = 0
    private var total = 0
    private var session = 0
    private var finished = false
    private var silentMode = false
    private var quizMode = false
    private val results = mutableListOf<Triple<String, String, Boolean>>()

    private lateinit var tvCount: TextView
    private lateinit var tvWord: TextView
    private lateinit var tvHeb: TextView
    private lateinit var tvMsg: TextView
    private lateinit var tvHeard: TextView

    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) listen() else msg("צריך לאשר גישה למיקרופון", Color.RED)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts.language = Locale.US
                ttsReady = true
                applyVoicePrefs()
                runOnUiThread { pendingSpeak?.invoke(); pendingSpeak = null }
            }
        }
        showWelcome()
    }

    // ---------------- UI helpers ----------------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun text(t: String, sp: Float, color: Int = Color.parseColor("#1D2B4F"), bold: Boolean = false) =
        TextView(this).apply {
            text = t; setTextSize(TypedValue.COMPLEX_UNIT_SP, sp); setTextColor(color)
            gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(6))
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun button(t: String, color: String = "#2F6DF6", onClick: () -> Unit) =
        Button(this).apply {
            text = t; textSize = 18f; setTextColor(Color.WHITE); setAllCaps(false)
            setBackgroundColor(Color.parseColor(color)); setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(10) }
        }

    private fun screen(vararg views: View) = render(views, true)
    private fun plainScreen(vararg views: View) = render(views, false)

    private fun render(views: Array<out View>, back: Boolean) {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
            setBackgroundColor(Color.parseColor("#FFF7E0"))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            views.forEach { addView(it) }
            if (back) addView(button("🏠 תפריט ראשי", "#888888") { goHome() })
        }
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.parseColor("#FFF7E0")); addView(col) })
    }

    private fun goHome() {
        session++; finished = true
        try { recognizer?.cancel() } catch (e: Exception) {}
        tts.stop()
        showHome()
    }

    private fun msg(t: String, color: Int = Color.parseColor("#1D2B4F")) {
        runOnUiThread { tvMsg.text = t; tvMsg.setTextColor(color) }
    }

    // ---------------- Voice settings ----------------
    private fun applyVoicePrefs() {
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        tts.setSpeechRate(p.getFloat("rate", 0.8f)); tts.setPitch(p.getFloat("pitch", 1f))
        p.getString("voice", null)?.let { n -> tts.voices?.find { it.name == n }?.let { tts.voice = it } }
    }

    private fun showVoices() {
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        val test = "Hello Avishag! Let's practice English."
        fun set(k: String, v: Float) { p.edit().putFloat(k, v).apply(); applyVoicePrefs(); speak(test) }
        val vs = (tts.voices ?: emptySet()).filter { it.locale.language == "en" }.sortedBy { it.name }
        val v = mutableListOf<View>(text("⚙️ בחירת קול", 26f, bold = true), text("מהירות", 16f))
        v += button("🐢 איטי", "#5D6A8A") { set("rate", 0.6f) }
        v += button("רגיל", "#5D6A8A") { set("rate", 0.8f) }
        v += button("🐇 מהיר", "#5D6A8A") { set("rate", 1.0f) }
        v += text("גובה הקול", 16f)
        v += button("נמוך", "#7B4FE0") { set("pitch", 0.8f) }
        v += button("רגיל", "#7B4FE0") { set("pitch", 1f) }
        v += button("🧒 גבוה", "#7B4FE0") { set("pitch", 1.4f) }
        v += text("קולות (לחצו כדי לשמוע ולבחור)", 16f)
        vs.forEach { vo ->
            v += button("${vo.locale.displayCountry} – ${vo.name}", "#2F6DF6") {
                tts.voice = vo; p.edit().putString("voice", vo.name).apply(); speak(test)
            }
        }
        if (vs.isEmpty()) v += text("לא נמצאו קולות באנגלית. אפשר להתקין בהגדרות ← המרת טקסט לדיבור", 15f)
        screen(*v.toTypedArray())
    }

    // ---------------- Screens ----------------
    private fun showWelcome() {
        val hello = "Hello Avishag! Welcome! Let's practice English."
        plainScreen(
            text("👋", 80f),
            text("Hello, Avishag!", 40f, bold = true).apply { layoutDirection = View.LAYOUT_DIRECTION_LTR },
            text("Welcome to your English practice!", 22f).apply { layoutDirection = View.LAYOUT_DIRECTION_LTR },
            text("שלום אבישג! ברוכה הבאה לתרגול באנגלית 🌟", 20f),
            button("🔊 Hello Avishag", "#5D6A8A") { speak(hello) },
            button("Let's start! בואו נתחיל 🚀", "#1FA968") { showHome() }
        )
        val greet: () -> Unit = { speak(hello) }
        if (ttsReady) greet() else pendingSpeak = greet
    }

    private fun showHome() {
        val now = System.currentTimeMillis()
        val exam = Calendar.getInstance().apply { set(2026, Calendar.NOVEMBER, 5, 0, 0, 0) }.timeInMillis
        val days = Math.ceil((exam - now) / 86400000.0).toInt()
        val countdown = when {
            days > 1 -> "📅 מבחן מיפוי ביום חמישי 5/11/26 – עוד $days ימים"
            days == 1 -> "📅 המבחן מחר! בהצלחה"
            days == 0 -> "📅 המבחן היום! בהצלחה"
            else -> ""
        }
        plainScreen(
            text("Jet 1", 30f, bold = true),
            text(countdown, 16f, Color.parseColor("#E5484D"), true),
            text("תרגלתי, ידעתי! 💪", 18f),
            button("🔤 האותיות – גדולה, קטנה וצליל") { showLetters() },
            button("👀 מילים נפוצות – שמעו וחזרו", "#7B4FE0") { start(sightWords.shuffled()) },
            button("🧠 מילים נפוצות – מה זה בעברית?", "#7B4FE0") { startQuiz(meaningQuiz()) },
            button("📖 קריאת מילים בנות 3 אותיות", "#E0A100") { start(cvcWords().shuffled().take(10), true) },
            button("🖼️ התאמת משפט לתמונה", "#1FA968") { startQuiz(sentenceQuiz()) },
            button("🎧 שמעו וחזרו – 10 מילים", "#2F6DF6") { start(words.shuffled().take(10)) },
            button("🎧 שמעו וחזרו – כל 40 המילים", "#5D6A8A") { start(words.shuffled()) },
            button("⚙️ בחירת קול", "#5D6A8A") { showVoices() }
        )
    }

    private fun showLetters() {
        screen(
            text("🔤 האותיות", 28f, bold = true),
            text(letters.joinToString(" ") { it.first }, 16f).apply { layoutDirection = View.LAYOUT_DIRECTION_LTR },
            button("🃏 לימוד: לחצו על אות ושמעו", "#1FA968") { showStudy() },
            button("🔊 שמעו את שם האות ובחרו") { startQuiz(letterHearQuiz()) },
            button("🎯 באיזו אות מתחילה המילה? (צליל)", "#7B4FE0") { startQuiz(soundQuiz()) },
            button("A ← a   מגדולה לקטנה", "#E0A100") { startQuiz(letterCaseQuiz(true)) },
            button("a ← A   מקטנה לגדולה", "#7B4FE0") { startQuiz(letterCaseQuiz(false)) }
        )
    }

    private fun showStudy() {
        val rows = letters.chunked(4).map { chunk ->
            LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_LTR
                chunk.forEach { (label, up) ->
                    val (w, e) = letterWords.getValue(up[0])
                    addView(Button(this@MainActivity).apply {
                        text = "$label\n$e"; textSize = 22f; setAllCaps(false)
                        typeface = Typeface.MONOSPACE
                        setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#2F6DF6"))
                        layoutParams = LinearLayout.LayoutParams(0, dp(84), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
                        setOnClickListener { speak("Letter $up. $up for $w") }
                    })
                }
            }
        }
        screen(text("🃏 לחצו על אות כדי לשמוע", 22f, bold = true), *rows.toTypedArray())
    }

    // ---------------- Say-and-repeat game ----------------
    private fun start(list: List<Pair<String, String>>, silent: Boolean = false) {
        session++; silentMode = silent; quizMode = false; total = list.size
        queue = list; index = 0; score = 0; results.clear()
        tvCount = text("", 18f, bold = true)
        tvWord = text("", 56f, bold = true).apply { layoutDirection = View.LAYOUT_DIRECTION_LTR }
        tvHeb = text("", 24f, Color.GRAY)
        tvMsg = text("", 20f, bold = true)
        tvHeard = text("", 15f, Color.GRAY)
        screen(
            tvCount, tvWord, tvHeb,
            button("🔊 שמעו שוב", "#5D6A8A") { speak(queue[index].first) },
            button("🎤 לחצו ודברו", "#E5484D") { autoRetry = 0; listen() },
            tvMsg, tvHeard,
            button("דלגו על המילה", "#888888") { try { recognizer?.cancel() } catch (e: Exception) {}; finishWord(false) }
        )
        loadWord()
    }

    private fun loadWord() {
        val (w, h) = queue[index]
        tries = 0; finished = false; autoRetry = 0
        tvCount.text = "${index + 1}/${queue.size}   ⭐ $score"
        tvWord.text = w; tvHeb.text = h; tvHeard.text = ""
        if (silentMode) msg("קראו את המילה בקול – לחצו על 🎤")
        else { msg("הקשיבו…"); speak(w) { msg("עכשיו אתם! לחצו על 🎤") } }
    }

    private fun finishWord(ok: Boolean) {
        if (finished) return
        finished = true
        val (w, h) = queue[index]
        results += Triple(w, h, ok)
        if (ok) { score++; msg("כל הכבוד! ✓", Color.parseColor("#1FA968")) }
        else { msg("נמשיך הלאה. המילה: $w", Color.RED); speak(w) }
        tvCount.text = "${index + 1}/${queue.size}   ⭐ $score"
        val sid = session
        tvWord.postDelayed({
            if (sid != session) return@postDelayed
            index++
            if (index < queue.size) loadWord() else showEnd()
        }, 1500)
    }

    private fun norm(s: String) =
        s.lowercase().replace("&", " and ").replace("10", "ten").replace(Regex("[^a-z ]"), "").trim()

    private fun key(s: String) = norm(s).replace(" ", "")

    private fun lev(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1); cur[0] = i
            for (j in 1..b.length)
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            prev = cur
        }
        return prev[b.length]
    }

    private fun matchesTarget(alts: List<String>): Boolean {
        val w = queue[index].first.lowercase()
        val ok = HashSet<String>()
        ok.add(key(w))
        if (w.startsWith("h")) ok.add(key(w).drop(1)) // recognizer often drops the H
        aliases[w]?.split(" ")?.forEach { ok.add(key(it)) }
        return alts.any { h ->
            (h.split(" ") + h).any { part ->
                val k = key(part)
                k.isNotEmpty() && (k in ok || (w.length >= 5 && lev(k, key(w)) <= 1))
            }
        }
    }

    private fun listen() {
        if (finished) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            micPermission.launch(Manifest.permission.RECORD_AUDIO); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            msg("זיהוי דיבור לא זמין במכשיר (התקינו את אפליקציית Google)", Color.RED); return
        }
        tts.stop()
        recognizer?.destroy()
        val sid = session
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    if (sid != session || finished) return
                    val alts = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.map { norm(it) } ?: emptyList()
                    tvHeard.text = "שמענו: " + (alts.firstOrNull() ?: "")
                    if (matchesTarget(alts)) finishWord(true)
                    else { tries++; if (tries >= 2) finishWord(false) else msg("כמעט! נסו שוב 🎤", Color.RED) }
                }
                override fun onPartialResults(p: Bundle?) {
                    if (sid != session || finished) return
                    val alts = p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.map { norm(it) } ?: return
                    if (matchesTarget(alts)) {
                        tvHeard.text = "שמענו: " + alts.first()
                        recognizer?.cancel()
                        finishWord(true)
                    }
                }
                override fun onError(e: Int) {
                    if (sid != session || finished) return
                    if ((e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) && autoRetry < 2) {
                        autoRetry++
                        msg("מקשיב…")
                        tvWord.postDelayed({ if (!finished && sid == session) listen() }, 300)
                        return
                    }
                    val why = when (e) {
                        SpeechRecognizer.ERROR_NO_MATCH -> "לא זוהתה מילה, דברו חזק וברור"
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "לא שמענו קול, קרבו את הטלפון לפה"
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "אין אינטרנט, זיהוי הדיבור צריך חיבור"
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "אין הרשאת מיקרופון"
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "המערכת עסוקה, נסו שוב"
                        else -> "שגיאה"
                    }
                    msg("$why (קוד $e). נסו שוב 🎤", Color.RED)
                }
                override fun onReadyForSpeech(p: Bundle?) { msg("מקשיב…") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 2000L)
            })
        }
    }

    // ---------------- Quizzes ----------------
    private fun pick(label: String, upper: Boolean) = if (upper) label[0].toString() else label[1].toString()

    private fun letterHearQuiz(): List<Q> = letters.shuffled().map { c ->
        val up = (0..1).random() == 0
        val others = letters.filter { it != c }.shuffled().take(3)
        val opts = (listOf(pick(c.first, up)) + others.map { pick(it.first, (0..1).random() == 0) }).shuffled()
        Q("🔊 איזו אות שמעתם?", "Letter ${c.second}", c.first, opts, opts.indexOf(pick(c.first, up)), false, 2)
    }

    private fun letterCaseQuiz(toSmall: Boolean): List<Q> = letters.shuffled().map { c ->
        val shown = pick(c.first, toSmall)
        val answer = pick(c.first, !toSmall)
        val others = letters.filter { it != c }.shuffled().take(3).map { pick(it.first, !toSmall) }
        val opts = (listOf(answer) + others).shuffled()
        Q("$shown  →  ?", "Letter ${c.second}", c.first, opts, opts.indexOf(answer), true, 2,
            if (toSmall) "מצאו את האות הקטנה" else "מצאו את האות הגדולה", false)
    }

    private fun soundQuiz(): List<Q> = letters.shuffled().map { c ->
        val x = c.second
        val (w, e) = letterWords.getValue(x[0])
        val opts = (listOf(x) + letters.filter { it != c }.shuffled().take(3).map { it.second }).shuffled()
        Q(e, w, "$x – $w", opts, opts.indexOf(x), true, 2,
            if (x == "X") "באיזו אות מסתיימת המילה?" else "באיזו אות מתחילה המילה?", true, 70f)
    }

    private fun meaningQuiz(): List<Q> = sightWords.shuffled().map { (w, h) ->
        val opts = (listOf(h) + sightWords.filter { it.second != h }.shuffled().take(3).map { it.second }).shuffled()
        Q(w, w, w, opts, opts.indexOf(h), true, 1, "מה המשמעות בעברית?", true)
    }

    private fun art(n: String) = if (n == "egg") "an" else "a"

    private fun sentenceQuiz(): List<Q> {
        val patterns = listOf<(String) -> String>(
            { n -> "This is a big $n." }, { n -> "I like the $n." },
            { n -> "I have ${art(n)} $n." }, { n -> "Look at the $n!" }
        )
        return items.shuffled().take(10).mapIndexed { i, (n, e) ->
            val sentence = patterns[i % patterns.size](n)
            val opts = (listOf(e) + items.filter { it.first != n }.shuffled().take(2).map { it.second }).shuffled()
            Q(sentence, sentence, sentence, opts, opts.indexOf(e), true, 3)
        }
    }

    private fun startQuiz(list: List<Q>) {
        session++; quiz = list; qi = 0; score = 0; results.clear(); quizMode = true; total = list.size
        showQ()
    }

    private fun showQ() {
        val q = quiz[qi]
        val sid = session
        finished = false
        val tvC = text("${qi + 1}/${quiz.size}   ⭐ $score", 18f, bold = true)
        val size = if (q.ps > 0f) q.ps else if (q.big) 30f else 22f
        val tvP = text(q.prompt, size, bold = true).apply {
            if (q.big) layoutDirection = View.LAYOUT_DIRECTION_LTR
            if (q.perRow == 2) typeface = Typeface.MONOSPACE
        }
        val fb = text("", 20f, bold = true)
        val buttons = mutableListOf<Button>()
        val rows = q.options.indices.chunked(q.perRow).map { idxs ->
            LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_LTR
                idxs.forEach { k ->
                    val b = Button(this@MainActivity).apply {
                        text = q.options[k]
                        textSize = if (q.perRow == 1) 26f else if (q.big) 44f else 32f
                        setAllCaps(false)
                        if (q.perRow == 2) typeface = Typeface.MONOSPACE
                        setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#2F6DF6"))
                        layoutParams = LinearLayout.LayoutParams(if (q.perRow == 1) -1 else 0, dp(100), 1f).apply { setMargins(dp(5), dp(8), dp(5), dp(8)) }
                        setOnClickListener {
                            if (finished) return@setOnClickListener
                            finished = true
                            val ok = k == q.answer
                            results += Triple(q.label, "", ok)
                            buttons[q.answer].setBackgroundColor(Color.parseColor("#1FA968"))
                            if (ok) { score++; fb.text = "כל הכבוד! ✓"; fb.setTextColor(Color.parseColor("#1FA968")) }
                            else { setBackgroundColor(Color.RED); fb.text = "לא נכון, התשובה הנכונה בירוק"; fb.setTextColor(Color.RED) }
                            if (q.big || !ok) speak(q.spoken)
                            postDelayed({ if (sid != session) return@postDelayed; qi++; if (qi < quiz.size) showQ() else showEnd() }, 1700)
                        }
                    }
                    buttons.add(b); addView(b)
                }
            }
        }
        screen(tvC, text(q.hint, 18f, Color.GRAY), tvP, button("🔊 שמעו שוב", "#5D6A8A") { speak(q.spoken) }, *rows.toTypedArray(), fb)
        if (q.autoSpeak) speak(q.spoken)
    }

    // ---------------- End ----------------
    private fun showEnd() {
        val pct = Math.round(score * 100f / total)
        val stars = when { pct >= 90 -> "⭐⭐⭐"; pct >= 60 -> "⭐⭐"; pct >= 30 -> "⭐"; else -> "💪" }
        val verdict = when { pct >= 90 -> "מצוין!"; pct >= 60 -> "יפה מאוד, עוד קצת תרגול!"; else -> "המשיכו להתאמן!" }
        val details = results.joinToString("\n") { (w, h, ok) -> (if (ok) "✅ " else "❌ ") + (if (h.isEmpty()) w else "$w – $h") }
        val wrong = results.filter { !it.third }.map { it.first to it.second }
        val views = mutableListOf<View>(
            text("🎉 כל הכבוד אבישג! 🎉", 28f, Color.parseColor("#1FA968"), true),
            text("Well done, Avishag!", 26f, bold = true).apply { layoutDirection = View.LAYOUT_DIRECTION_LTR },
            text(stars, 38f), text("$pct", 76f, bold = true),
            text("$score מתוך $total נכונות – $verdict", 17f),
            text(details, 16f).apply { gravity = Gravity.START }
        )
        if (wrong.isNotEmpty() && !quizMode) views += button("תרגלו רק את הטעויות", "#E0A100") { start(wrong.shuffled(), silentMode) }
        screen(*views.toTypedArray())
        speak("Well done, Avishag!")
    }

    // ---------------- Speech out ----------------
    private fun speak(t: String, onDone: (() -> Unit)? = null) {
        if (!ttsReady) { onDone?.invoke(); return }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { runOnUiThread { onDone?.invoke() } }
            @Deprecated("Deprecated in Java") override fun onError(id: String?) { runOnUiThread { onDone?.invoke() } }
        })
        tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "w")
    }

    override fun onDestroy() {
        recognizer?.destroy(); tts.shutdown(); super.onDestroy()
    }
}
