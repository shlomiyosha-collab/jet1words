package com.example.jet1words

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.util.Calendar
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private val words = listOf(
        "bag" to "תיק", "banana" to "בננה", "Dad" to "אבא", "bad" to "רע", "egg" to "ביצה",
        "bed" to "מיטה", "sad" to "עצוב", "hat" to "כובע", "test" to "מבחן", "pen" to "עט",
        "hen" to "תרנגול", "hand" to "יד", "help" to "לעזור", "big" to "גדול", "stop" to "לעצור",
        "hot" to "חם", "cold" to "קר", "lost" to "אבד", "dog" to "כלב", "job" to "עבודה",
        "plan" to "תוכנית", "pet" to "חיית מחמד", "leg" to "רגל", "grandpa" to "סבא", "lamp" to "מנורה",
        "mat" to "שטיחון", "sing" to "לשיר", "ten" to "עשר", "mad" to "כועס", "glad" to "שמח",
        "cat" to "חתול", "on" to "על", "in" to "בתוך", "add" to "להוסיף", "mom" to "אמא",
        "lemon" to "לימון", "melon" to "מלון", "grandma" to "סבתא", "and" to "ו (מילת חיבור)", "panda" to "פנדה"
    )

    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null

    private var queue = listOf<Pair<String, String>>()
    private var index = 0
    private var score = 0
    private var tries = 0
    private var finished = false
    private var autoRetry = 0
    private var silentMode = false
    private var quizMode = false
    private var total = 0
    private var pendingSpeak: (() -> Unit)? = null

    private val sightWords = listOf(
        "Look" to "תסתכלו", "I am" to "אני", "have" to "יש לי", "has" to "יש לו / לה",
        "the" to "ה (היידוע)", "like" to "אוהב", "he" to "הוא", "she" to "היא"
    )
    private val letters = listOf(
        "Aa" to "ay", "Bb" to "bee", "Nn" to "en", "Dd" to "dee", "Gg" to "jee", "Ee" to "ee",
        "Tt" to "tee", "Ii" to "eye", "Pp" to "pee", "Hh" to "aitch", "Ss" to "ess", "Mm" to "em",
        "Cc" to "see", "Oo" to "oh", "Ll" to "el", "Jj" to "jay"
    )
    private val items = listOf(
        "cat" to "🐱", "dog" to "🐶", "hen" to "🐔", "panda" to "🐼", "hat" to "👒", "bag" to "🎒",
        "pen" to "🖊️", "bed" to "🛏️", "egg" to "🥚", "banana" to "🍌", "lemon" to "🍋", "melon" to "🍈"
    )

    private data class Q(
        val prompt: String, val spoken: String, val label: String,
        val options: List<String>, val answer: Int, val big: Boolean, val perRow: Int
    )
    private var quiz = listOf<Q>()
    private var qi = 0
    private val results = mutableListOf<Triple<String, String, Boolean>>()

    private lateinit var tvCount: TextView
    private lateinit var tvWord: TextView
    private lateinit var tvHeb: TextView
    private lateinit var tvMsg: TextView
    private lateinit var tvHeard: TextView

    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) listen() else msg("צריך לאשר גישה למיקרופון", Color.RED)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts.language = Locale.US
                tts.setSpeechRate(0.8f)
                ttsReady = true
                runOnUiThread { pendingSpeak?.invoke(); pendingSpeak = null }
            }
        }
        showWelcome()
    }

    // ---------- UI helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun text(t: String, sp: Float, color: Int = Color.parseColor("#1D2B4F"), bold: Boolean = false) =
        TextView(this).apply {
            text = t; setTextSize(TypedValue.COMPLEX_UNIT_SP, sp); setTextColor(color)
            gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(6))
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun button(t: String, color: String = "#2F6DF6", onClick: () -> Unit) =
        Button(this).apply {
            text = t; textSize = 18f; setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor(color)); setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(10) }
        }

    private fun screen(vararg views: View) {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
            setBackgroundColor(Color.parseColor("#FFF7E0"))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            views.forEach { addView(it) }
        }
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.parseColor("#FFF7E0")); addView(col) })
    }

    private fun msg(t: String, color: Int = Color.parseColor("#1D2B4F")) {
        runOnUiThread { tvMsg.text = t; tvMsg.setTextColor(color) }
    }

    // ---------- Screens ----------
    private fun showWelcome() {
        val hello = "Hello Avishag! Welcome! Let's practice English."
        screen(
            text("👋", 80f),
            text("Hello, Avishag!", 40f, bold = true).apply { layoutDirection = View.LAYOUT_DIRECTION_LTR },
            text("Welcome to your English practice!", 22f).apply { layoutDirection = View.LAYOUT_DIRECTION_LTR },
            text("שלום אבישג! ברוכה הבאה לתרגול באנגלית 🌟", 20f),
            button("🔊 Hello Avishag", "#5D6A8A") { speak(hello) },
            button("Let's start! בואו נתחיל 🚀", "#1FA968") { showHome() }
        )
        val greet: () -> Unit = { speak(hello) }
        if (ttsReady) greet() else pendingSpeak = greet
    }

    private fun showHome() {
        val now = System.currentTimeMillis()
        val exam = Calendar.getInstance().apply { set(2026, Calendar.OCTOBER, 15, 0, 0, 0) }.timeInMillis
        val days = Math.ceil((exam - now) / 86400000.0).toInt()
        val countdown = when {
            days > 1 -> "📅 המבחן ביום חמישי 15/10/26 – עוד $days ימים"
            days == 1 -> "📅 המבחן מחר! בהצלחה"
            days == 0 -> "📅 המבחן היום! בהצלחה"
            else -> ""
        }
        screen(
            text("Jet 1 – Unit 3", 30f, bold = true),
            text(countdown, 16f, Color.parseColor("#E5484D"), true),
            text("תרגלתי, ידעתי! 💪", 18f),
            button("🔤 האותיות (16 שאלות)") { startQuiz(letterQuiz()) },
            button("👀 מילים נפוצות: Look, I am, have…", "#7B4FE0") { start(sightWords.shuffled()) },
            button("🖼️ התאמת משפט לתמונה", "#1FA968") { startQuiz(sentenceQuiz()) },
            button("📖 קריאה: רואים מילה ואומרים", "#E0A100") { start(words.shuffled().take(10), true) },
            button("🎧 שמעו וחזרו – 10 מילים") { start(words.shuffled().take(10)) },
            button("🎧 שמעו וחזרו – כל 40 המילים", "#5D6A8A") { start(words.shuffled()) }
        )
    }

    private fun start(list: List<Pair<String, String>>, silent: Boolean = false) {
        silentMode = silent; quizMode = false; total = list.size
        queue = list; index = 0; score = 0; results.clear()
        tvCount = text("", 18f, bold = true)
        tvWord = text("", 56f, bold = true).apply { layoutDirection = View.LAYOUT_DIRECTION_LTR }
        tvHeb = text("", 24f, Color.GRAY)
        tvMsg = text("", 20f, bold = true)
        tvHeard = text("", 15f, Color.GRAY)
        screen(
            tvCount, tvWord, tvHeb,
            button("🔊 שמעו שוב", "#5D6A8A") { speak(queue[index].first) },
            button("🎤 לחצו ודברו", "#E5484D") { autoRetry = 0; listen() },
            tvMsg, tvHeard,
            button("דלגו על המילה", "#888888") { recognizer?.cancel(); finishWord(false) }
        )
        loadWord()
    }

    private fun loadWord() {
        val (w, h) = queue[index]
        tries = 0; finished = false; autoRetry = 0
        tvCount.text = "${index + 1}/${queue.size}   ⭐ $score"
        tvWord.text = w; tvHeb.text = h; tvHeard.text = ""
        msg("הקשיבו…")
        if (silentMode) msg("קראו את המילה בקול – לחצו על 🎤") else speak(w) { msg("עכשיו אתם! לחצו על 🎤") }
    }

    private fun showEnd() {
        val pct = Math.round(score * 100f / total)
        val stars = when { pct >= 90 -> "⭐⭐⭐"; pct >= 60 -> "⭐⭐"; pct >= 30 -> "⭐"; else -> "💪" }
        val verdict = when { pct >= 90 -> "מצוין!"; pct >= 60 -> "יפה מאוד, עוד קצת תרגול!"; else -> "המשיכו להתאמן!" }
        val details = results.joinToString("\n") { (w, h, ok) -> (if (ok) "✅ " else "❌ ") + if (h.isEmpty()) w else "$w – $h" }
        val wrong = results.filter { !it.third }.map { it.first to it.second }
        val views = mutableListOf<View>(
            text("🎉 כל הכבוד אבישג! 🎉", 28f, Color.parseColor("#1FA968"), true),
            text("Well done, Avishag!", 26f, bold = true).apply { layoutDirection = View.LAYOUT_DIRECTION_LTR },
            text(stars, 38f), text("$pct", 76f, bold = true),
            text("$score מתוך $total נכונות – $verdict", 17f),
            text(details, 16f).apply { gravity = Gravity.START }
        )
        views += button("שחקו שוב") { showHome() }
        if (wrong.isNotEmpty() && !quizMode) views += button("תרגלו רק את הטעויות", "#E0A100") { start(wrong.shuffled(), silentMode) }
        screen(*views.toTypedArray())
        speak("Well done, Avishag!")
    }

    // ---------- Quizzes: letters and sentence-to-picture ----------
    private fun art(n: String) = if (n == "egg") "an" else "a"

    private fun letterQuiz(): List<Q> = letters.shuffled().map { c ->
        val opts = (listOf(c.first) + letters.filter { it != c }.shuffled().take(3).map { it.first }).shuffled()
        Q("🔊 איזו אות שמעתם?", c.second, c.first, opts, opts.indexOf(c.first), false, 2)
    }

    private fun sentenceQuiz(): List<Q> {
        val patterns = listOf<(String) -> String>(
            { n -> "This is a big $n." }, { n -> "I like the $n." },
            { n -> "I have ${art(n)} $n." }, { n -> "Look at the $n!" }
        )
        return items.shuffled().take(10).mapIndexed { i, (n, e) ->
            val sentence = patterns[i % patterns.size](n)
            val opts = (listOf(e) + items.filter { it.first != n }.shuffled().take(2).map { it.second }).shuffled()
            Q(sentence, sentence, sentence, opts, opts.indexOf(e), true, 3)
        }
    }

    private fun startQuiz(list: List<Q>) {
        quiz = list; qi = 0; score = 0; results.clear(); quizMode = true; total = list.size
        showQ()
    }

    private fun showQ() {
        val q = quiz[qi]
        finished = false
        val tvC = text("${qi + 1}/${quiz.size}   ⭐ $score", 18f, bold = true)
        val tvP = text(q.prompt, if (q.big) 30f else 22f, bold = true).apply {
            if (q.big) layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val fb = text("", 20f, bold = true)
        val buttons = mutableListOf<Button>()
        val rows = q.options.indices.chunked(q.perRow).map { idxs ->
            LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_LTR
                idxs.forEach { k ->
                    val b = Button(this@MainActivity).apply {
                        text = q.options[k]; textSize = if (q.big) 44f else 32f
                        setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#2F6DF6"))
                        layoutParams = LinearLayout.LayoutParams(0, dp(100), 1f).apply { setMargins(dp(5), dp(8), dp(5), dp(8)) }
                        setOnClickListener {
                            if (finished) return@setOnClickListener
                            finished = true
                            val ok = k == q.answer
                            results += Triple(q.label, "", ok)
                            buttons[q.answer].setBackgroundColor(Color.parseColor("#1FA968"))
                            if (ok) { score++; fb.text = "כל הכבוד! ✓"; fb.setTextColor(Color.parseColor("#1FA968")) }
                            else { setBackgroundColor(Color.RED); fb.text = "לא נכון, התשובה הנכונה בירוק"; fb.setTextColor(Color.RED) }
                            if (q.big || !ok) speak(q.spoken)
                            postDelayed({ qi++; if (qi < quiz.size) showQ() else showEnd() }, 1600)
                        }
                    }
                    buttons.add(b); addView(b)
                }
            }
        }
        screen(tvC, tvP, button("🔊 שמעו שוב", "#5D6A8A") { speak(q.spoken) }, *rows.toTypedArray(), fb)
        speak(q.spoken)
    }

    // ---------- Game logic ----------
    private fun finishWord(ok: Boolean) {
        if (finished) return
        finished = true
        val (w, h) = queue[index]
        results += Triple(w, h, ok)
        if (ok) { score++; msg("כל הכבוד! ✓", Color.parseColor("#1FA968")) }
        else { msg("נמשיך הלאה. המילה: $w", Color.RED); speak(w) }
        tvWord.postDelayed({
            index++
            if (index < queue.size) loadWord() else showEnd()
        }, 1300)
    }

    private fun norm(s: String) = s.lowercase().replace(Regex("[^a-z ]"), "").trim()

    private fun listen() {
        if (finished) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            micPermission.launch(Manifest.permission.RECORD_AUDIO); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            msg("זיהוי דיבור לא זמין במכשיר (התקינו את אפליקציית Google)", Color.RED); return
        }
        tts.stop()
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    val alts = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.map { norm(it) } ?: emptyList()
                    tvHeard.text = "שמענו: " + (alts.firstOrNull() ?: "")
                    val target = norm(queue[index].first)
                    if (alts.any { it == target || it.split(" ").contains(target) }) finishWord(true)
                    else { tries++; if (tries >= 2) finishWord(false) else msg("כמעט! נסו שוב 🎤", Color.RED) }
                }
                override fun onError(e: Int) {
                    if (finished) return
                    if ((e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) && autoRetry < 2) {
                        autoRetry++
                        msg("מקשיב…")
                        tvWord.postDelayed({ if (!finished) listen() }, 300)
                        return
                    }
                    val why = when (e) {
                        SpeechRecognizer.ERROR_NO_MATCH -> "לא זוהתה מילה, דברו חזק וברור"
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "לא שמענו קול, קרבו את הטלפון לפה"
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "אין אינטרנט, זיהוי הדיבור צריך חיבור"
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "אין הרשאת מיקרופון"
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "המערכת עסוקה, נסו שוב"
                        else -> "שגיאה"
                    }
                    msg("$why (קוד $e). נסו שוב 🎤", Color.RED)
                }
                override fun onReadyForSpeech(p: Bundle?) { msg("מקשיב…") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {
                    if (finished) return
                    val alts = p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.map { norm(it) } ?: return
                    val target = norm(queue[index].first)
                    if (alts.any { it == target || it.split(" ").contains(target) }) {
                        tvHeard.text = "שמענו: $target"
                        recognizer?.cancel()
                        finishWord(true)
                    }
                }
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 2000L)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            })
        }
    }

    private fun speak(t: String, onDone: (() -> Unit)? = null) {
        if (!ttsReady) { onDone?.invoke(); return }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { runOnUiThread { onDone?.invoke() } }
            @Deprecated("Deprecated in Java") override fun onError(id: String?) { runOnUiThread { onDone?.invoke() } }
        })
        tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "w")
    }

    override fun onDestroy() {
        recognizer?.destroy(); tts.shutdown(); super.onDestroy()
    }
}
