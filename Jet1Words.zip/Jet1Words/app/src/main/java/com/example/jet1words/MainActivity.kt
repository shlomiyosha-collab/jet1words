package com.example.jet1words

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private val words = listOf(
        "bag" to "תיק", "banana" to "בננה", "Dad" to "אבא", "bad" to "רע", "egg" to "ביצה",
        "bed" to "מיטה", "sad" to "עצוב", "hat" to "כובע", "test" to "מבחן", "pen" to "עט",
        "hen" to "תרנגול", "hand" to "יד", "help" to "לעזור", "big" to "גדול", "stop" to "לעצור",
        "hot" to "חם", "cold" to "קר", "lost" to "אבד", "dog" to "כלב", "job" to "עבודה",
        "plan" to "תוכנית", "pet" to "חיית מחמד", "leg" to "רגל", "grandpa" to "סבא", "lamp" to "מנורה",
        "mat" to "שטיחון", "sing" to "לשיר", "ten" to "עשר", "mad" to "כועס", "glad" to "שמח",
        "cat" to "חתול", "on" to "על", "in" to "בתוך", "add" to "להוסיף", "mom" to "אמא",
        "lemon" to "לימון", "melon" to "מלון", "grandma" to "סבתא", "and" to "ו (מילת חיבור)", "panda" to "פנדה"
    )

    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null

    private var queue = listOf<Pair<String, String>>()
    private var index = 0
    private var score = 0
    private var tries = 0
    private var finished = false
    private val results = mutableListOf<Triple<String, String, Boolean>>()

    private lateinit var tvCount: TextView
    private lateinit var tvWord: TextView
    private lateinit var tvHeb: TextView
    private lateinit var tvMsg: TextView
    private lateinit var tvHeard: TextView

    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) listen() else msg("צריך לאשר גישה למיקרופון", Color.RED)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts.language = Locale.US
                tts.setSpeechRate(0.8f)
                ttsReady = true
            }
        }
        showHome()
    }

    // ---------- UI helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun text(t: String, sp: Float, color: Int = Color.parseColor("#1D2B4F"), bold: Boolean = false) =
        TextView(this).apply {
            text = t; setTextSize(TypedValue.COMPLEX_UNIT_SP, sp); setTextColor(color)
            gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(6))
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun button(t: String, color: String = "#2F6DF6", onClick: () -> Unit) =
        Button(this).apply {
            text = t; textSize = 18f; setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor(color)); setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(10) }
        }

    private fun screen(vararg views: View) {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
            setBackgroundColor(Color.parseColor("#FFF7E0"))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            views.forEach { addView(it) }
        }
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.parseColor("#FFF7E0")); addView(col) })
    }

    private fun msg(t: String, color: Int = Color.parseColor("#1D2B4F")) {
        runOnUiThread { tvMsg.text = t; tvMsg.setTextColor(color) }
    }

    // ---------- Screens ----------
    private fun showHome() {
        screen(
            text("Jet 1 – Unit 3", 30f, bold = true),
            text("המילים שאני יודע לקרוא ולפרש באנגלית", 16f),
            text("🎧🗣️", 60f),
            text("האפליקציה אומרת מילה באנגלית, ואתם חוזרים עליה בקול. בסוף מקבלים ציון.", 16f),
            button("משחק קצר – 10 מילים") { start(words.shuffled().take(10)) },
            button("כל 40 המילים", "#E0A100") { start(words.shuffled()) }
        )
    }

    private fun start(list: List<Pair<String, String>>) {
        queue = list; index = 0; score = 0; results.clear()
        tvCount = text("", 18f, bold = true)
        tvWord = text("", 56f, bold = true).apply { layoutDirection = View.LAYOUT_DIRECTION_LTR }
        tvHeb = text("", 24f, Color.GRAY)
        tvMsg = text("", 20f, bold = true)
        tvHeard = text("", 15f, Color.GRAY)
        screen(
            tvCount, tvWord, tvHeb,
            button("🔊 שמעו שוב", "#5D6A8A") { speak(queue[index].first) },
            button("🎤 לחצו ודברו", "#E5484D") { listen() },
            tvMsg, tvHeard,
            button("דלגו על המילה", "#888888") { recognizer?.cancel(); finishWord(false) }
        )
        loadWord()
    }

    private fun loadWord() {
        val (w, h) = queue[index]
        tries = 0; finished = false
        tvCount.text = "${index + 1}/${queue.size}   ⭐ $score"
        tvWord.text = w; tvHeb.text = h; tvHeard.text = ""
        msg("הקשיבו…")
        speak(w) { msg("עכשיו אתם! לחצו על 🎤") }
    }

    private fun showEnd() {
        val pct = Math.round(score * 100f / queue.size)
        val stars = when { pct >= 90 -> "⭐⭐⭐"; pct >= 60 -> "⭐⭐"; pct >= 30 -> "⭐"; else -> "💪" }
        val verdict = when { pct >= 90 -> "מצוין!"; pct >= 60 -> "יפה מאוד, עוד קצת תרגול!"; else -> "המשיכו להתאמן!" }
        val details = results.joinToString("\n") { (w, h, ok) -> (if (ok) "✅ " else "❌ ") + "$w – $h" }
        val wrong = results.filter { !it.third }.map { it.first to it.second }
        val views = mutableListOf<View>(
            text("סיימתם!", 22f), text(stars, 38f), text("$pct", 76f, bold = true),
            text("$score מתוך ${queue.size} מילים נכונות – $verdict", 17f),
            text(details, 16f).apply { gravity = Gravity.START }
        )
        views += button("שחקו שוב") { showHome() }
        if (wrong.isNotEmpty()) views += button("תרגלו רק את הטעויות", "#E0A100") { start(wrong.shuffled()) }
        screen(*views.toTypedArray())
        speak(if (pct >= 60) "Great job!" else "Good try!")
    }

    // ---------- Game logic ----------
    private fun finishWord(ok: Boolean) {
        if (finished) return
        finished = true
        val (w, h) = queue[index]
        results += Triple(w, h, ok)
        if (ok) { score++; msg("כל הכבוד! ✓", Color.parseColor("#1FA968")) }
        else msg("נמשיך הלאה. המילה: $w", Color.RED)
        tvWord.postDelayed({
            index++
            if (index < queue.size) loadWord() else showEnd()
        }, 1300)
    }

    private fun norm(s: String) = s.lowercase().replace(Regex("[^a-z ]"), "").trim()

    private fun listen() {
        if (finished) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            micPermission.launch(Manifest.permission.RECORD_AUDIO); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            msg("זיהוי דיבור לא זמין במכשיר (התקינו את אפליקציית Google)", Color.RED); return
        }
        tts.stop()
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    val alts = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.map { norm(it) } ?: emptyList()
                    tvHeard.text = "שמענו: " + (alts.firstOrNull() ?: "")
                    val target = norm(queue[index].first)
                    if (alts.any { it == target || it.split(" ").contains(target) }) finishWord(true)
                    else { tries++; if (tries >= 2) finishWord(false) else msg("כמעט! נסו שוב 🎤", Color.RED) }
                }
                override fun onError(e: Int) { if (!finished) msg("לא שמענו. נסו שוב 🎤", Color.RED) }
                override fun onReadyForSpeech(p: Bundle?) { msg("מקשיב…") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            })
        }
    }

    private fun speak(t: String, onDone: (() -> Unit)? = null) {
        if (!ttsReady) { onDone?.invoke(); return }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { runOnUiThread { onDone?.invoke() } }
            @Deprecated("Deprecated in Java") override fun onError(id: String?) { runOnUiThread { onDone?.invoke() } }
        })
        tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "w")
    }

    override fun onDestroy() {
        recognizer?.destroy(); tts.shutdown(); super.onDestroy()
    }
}
